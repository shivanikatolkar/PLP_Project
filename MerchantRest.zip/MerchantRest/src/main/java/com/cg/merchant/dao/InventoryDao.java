package com.cg.merchant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.merchant.model.Inventory;

@Repository("inventoryDao")
public interface InventoryDao extends JpaRepository<Inventory, Integer>{
	

	
}
