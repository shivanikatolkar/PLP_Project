package com.cg.merchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantRestApplication.class, args);
	}
}
