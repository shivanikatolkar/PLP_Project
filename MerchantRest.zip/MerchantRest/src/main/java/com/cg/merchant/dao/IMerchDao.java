package com.cg.merchant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.merchant.model.Merchant;

@Repository("merchDao")
public interface IMerchDao extends JpaRepository<Merchant, Integer> {

}
