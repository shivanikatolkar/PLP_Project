package com.cg.merchant.service;

import java.util.List;

import com.cg.merchant.model.Brand;
import com.cg.merchant.model.Category;
import com.cg.merchant.model.Inventory;
import com.cg.merchant.model.Merchant;

public interface InventoryService {

	public void save(Inventory product);
    public void delete(Integer productId) ;
    public List<Inventory> getAll();
	List<Inventory> getAllInventory();
	public List<Brand> getAllBrands();
	public List<Category> getAllCategories();
	public Merchant getMerch(int merchantId);
	public List<Merchant> getAllMerch();
	public Inventory getProduct(String productName);
}
