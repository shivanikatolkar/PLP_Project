package com.cg.merchant.service;

import java.util.List;

import com.cg.merchant.model.Inventory;

public interface InventoryService {

	public void save(Inventory product);
    public void delete(Integer productId) ;
    public List<Inventory> getAll();
	List<Inventory> getAllInventory();
}
