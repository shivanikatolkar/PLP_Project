package com.cg.merchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantFrontEndApplication.class, args);
	}
}
