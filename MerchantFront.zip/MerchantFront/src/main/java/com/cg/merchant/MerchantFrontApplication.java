package com.cg.merchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MerchantFrontApplication {

	public static void main(String[] args) {
		SpringApplication.run(MerchantFrontApplication.class, args);
	}
}
