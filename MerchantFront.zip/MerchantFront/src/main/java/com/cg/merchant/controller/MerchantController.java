package com.cg.merchant.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cg.merchant.model.Inventory;

@Controller
public class MerchantController {
	
	@RequestMapping("/merchant")
	public String merchantHomeFull() {
		final String uri="http://localhost:8081/capstoreApp/api/v2/prods";
		RestTemplate restTemplate=new RestTemplate();
		
		Inventory[] products= restTemplate.getForObject(uri, Inventory[].class);
		return "Merchant_home_full";
	}
	
	
	@RequestMapping("/merchantHome")
	public String homePage() {
		
		return "Merchant_home_full";
	}
	
	
	@RequestMapping("/inventPage")
	public String inventoryPage() {
		
		return "inventory";
		
	}
	
	@RequestMapping("/myProfile")
	public String myProfilePage() {
		
		return "myprofile";
		
	}
	
	@RequestMapping("/showProduct")
	public String showProduct() {
		
		return "myproductdetails";
		
	}
	
	@RequestMapping("/addProduct")
	public String addProduct() {
		
		return "addproduct";
		
	}
	
	@RequestMapping("/updateProduct")
	public String updateProduct() {
		
		return "updateproduct";
		
	}
	
	@RequestMapping("/removeProduct")
	public String remoteProduct() {
		
		return "removeproduct";
		
	}
	
	@RequestMapping("/discount")
	public String discountAndPromo() {
		
		return "discountpromos";
		
	}
	
	@RequestMapping("/summary")
	public String orderSummary() {
		
		return "ordersummary";
		
	}
	
	@RequestMapping("/valretgoods")
	public String validateReturnGoods() {
		
		return "validategoods";
		
	}
	
	@RequestMapping("/inbox")
	public String inbox() {
		
		return "inbox";
		
	}
	
}