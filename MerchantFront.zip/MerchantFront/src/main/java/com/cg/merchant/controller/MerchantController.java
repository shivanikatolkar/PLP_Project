package com.cg.merchant.controller;


import java.util.HashMap;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cg.merchant.model.Brand;
import com.cg.merchant.model.Category;
import com.cg.merchant.model.Customer;
import com.cg.merchant.model.Inventory;
import com.cg.merchant.model.Merchant;


@Controller
public class MerchantController {
	
	
	@RequestMapping("/addProduct")
	public String addProduct(ModelMap map) {
		final String uri="http://localhost:8081/capstoreApp/api/v2/brands";
		RestTemplate restTemplate=new RestTemplate();
		Brand[] brands=  restTemplate.getForObject(uri, Brand[].class);
		
		final String uri_cat="http://localhost:8081/capstoreApp/api/v2/categories";
	
		Category[] categories=  restTemplate.getForObject(uri_cat, Category[].class);
	
		map.put("addproducts", new Inventory());
		map.put("brands", brands);
		map.put("categories", categories);
		return "addproduct";
		
	}
	
	@PostMapping("/addps")
	public String addProduct(
			@Valid @ModelAttribute("addproducts") Inventory invent,Model model,
			BindingResult result) {
		if(!result.hasErrors()) {
			final String uri="http://localhost:8081/capstoreApp/api/v2/addProd";
			RestTemplate rest=new RestTemplate();
			rest.postForEntity(uri, invent, Inventory.class);
		}
				return "redirect:addproduct";
		
	}
	
	@RequestMapping("/merchant")
	public String merchantHomeFull() {
		
		return "Merchant_home_full";
	}
	
	
	@RequestMapping("/merchantHome")
	public String homePage() {
		
		return "Merchant_home_full";
	}
	
	
	@RequestMapping("/inventPage")
	public String inventoryPage() {
		
		return "inventory";
		
	}
	
	@RequestMapping("/myProfile")
	public String myProfilePage(HttpSession session,ModelMap map) {
		final String uri="http://localhost:8081/capstoreApp/api/v2/merchantProfile/1";
		RestTemplate restTemplate=new RestTemplate();
		
		Merchant merchant= restTemplate.getForObject(uri, Merchant.class);
		map.put("merc",merchant);
		System.out.println("Heyyyyyyyyyy");
		return "myprofile";
		
	}
	
/*	@RequestMapping("/saveMerch/{merchantId}")
	public String showMerch(HttpSession session,ModelMap map) {
	
			final String uri="http://localhost:8081/capstoreApp/api/v2/merchantProfile/1";
			RestTemplate restTemplate=new RestTemplate();
			
			Merchant merchant= restTemplate.getForObject(uri, Merchant.class);
			map.put("merchant",merchant);
					
		return "myprofile";
		
	}*/
	
	
	@RequestMapping("/showProduct")
	public String showProduct() {
		
		return "myproductdetails";
		
	}
	
	
	@RequestMapping("/updateProduct")
	public String updateProduct(ModelMap map) {
		final String uri="http://localhost:8081/capstoreApp/api/v2/prods";
		RestTemplate restTemplate=new RestTemplate();
		Inventory[] invents=  restTemplate.getForObject(uri, Inventory[].class);
	
		map.put("updateproducts", new Inventory());
		map.put("prods", invents);
		return "updateproduct";
		
	}
	
	@RequestMapping("/search/{productName}")
		public String productName(ModelMap map,@PathVariable("productName") String productName,@ModelAttribute("updateproducts")Inventory invent) {
		final String uri="http://localhost:8081/capstoreApp/api/v2/prods/{productName}";
		RestTemplate restTemplate=new RestTemplate();
		
		java.util.Map<String, Object> params=new HashMap<>();
		params.put("productName", productName);
		ResponseEntity<Inventory> i=restTemplate.getForEntity(uri, Inventory.class,params);
		map.put("products", i);
			return "updateproduct";
	}
	
	@RequestMapping("/removeProduct")
	public String remoteProduct(ModelMap map) {
		final String uri="http://localhost:8081/capstoreApp/api/v2/prods";
		RestTemplate restTemplate=new RestTemplate();
		Inventory[] invents=  restTemplate.getForObject(uri, Inventory[].class);
	
		map.put("removeproducts", new Inventory());
		map.put("prods", invents);
		return "removeproduct";
		
	}
	
	@RequestMapping("/discount")
	public String discountAndPromo() {
		
		return "discountpromos";
		
	}
	
	@RequestMapping("/summary")
	public String orderSummary() {
		
		return "ordersummary";
		
	}
	
	@RequestMapping("/valretgoods")
	public String validateReturnGoods() {
		
		return "validategoods";
		
	}
	
	@RequestMapping("/inbox")
	public String inbox() {
		
		return "inbox";
		
	}
	
}